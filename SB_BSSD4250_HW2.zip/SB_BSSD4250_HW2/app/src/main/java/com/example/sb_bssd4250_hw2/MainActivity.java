package com.example.sb_bssd4250_hw2;


import android.graphics.Color;
import android.os.Bundle;
import android.support.constraint.ConstraintLayout;
import android.support.constraint.ConstraintSet;
//import android.support.constraint.helper;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // setContentView(R.layout.activity_main);

        final ConstraintLayout constraintLayout = new ConstraintLayout( this );
        ConstraintLayout.LayoutParams clParams =
                new ConstraintLayout.LayoutParams(ConstraintLayout.LayoutParams.MATCH_PARENT,
                        ConstraintLayout.LayoutParams.MATCH_PARENT);
        constraintLayout.setBackgroundColor(Color.WHITE);
        constraintLayout.setId(View.generateViewId());



        // Set up the Red Button
        Button redButton = new Button( this);
        redButton.setText(R.string.press);
        redButton.setTextColor(Color.WHITE);
        redButton.setBackgroundColor(Color.RED);
        redButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("MainActivity","button clicked");
                constraintLayout.setBackgroundColor(Color.BLUE);
                CharSequence text = "The background color is changed to Blue";
                int duration = Toast.LENGTH_SHORT;

                Toast toast = Toast.makeText(getApplicationContext(), text, duration);
                toast.show();
            }
        });
        redButton.setId(View.generateViewId());

        // set up the blue button
        Button blueButton = new Button( this);
        blueButton.setText(R.string.click);
        blueButton.setTextColor(Color.WHITE);
        blueButton.setBackgroundColor(Color.BLUE);
        blueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("MainActivity","button clicked");
                constraintLayout.setBackgroundColor(Color.GREEN);
                CharSequence text = "The background color is changed to Green";
                int duration = Toast.LENGTH_SHORT;

                Toast toast = Toast.makeText(getApplicationContext(), text, duration);
                toast.show();
            }
        });
        blueButton.setId(View.generateViewId());

        // set up the green button
        Button greenButton = new Button( this);
        greenButton.setText(R.string.push);
        greenButton.setTextColor(Color.WHITE);
        greenButton.setBackgroundColor(Color.GREEN);
        greenButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("MainActivity","button clicked");
                constraintLayout.setBackgroundColor(Color.RED);
                CharSequence text = "The background color is changed to Red";
                int duration = Toast.LENGTH_SHORT;

                Toast toast = Toast.makeText(getApplicationContext(), text, duration);
                toast.show();
            }
        });
        greenButton.setId(View.generateViewId());

        // add widgets to the layout
        constraintLayout.addView(redButton);
        constraintLayout.addView(blueButton);
        constraintLayout.addView(greenButton);
        setContentView(constraintLayout, clParams);

        int rbid = redButton.getId();
        int bbid = blueButton.getId();
        int gbid = greenButton.getId();
        int pid = ConstraintSet.PARENT_ID;
        ConstraintSet centerSet = new ConstraintSet();

        // position the blue button
        centerSet.constrainHeight(bbid,ConstraintSet.WRAP_CONTENT);
        centerSet.constrainWidth(bbid,ConstraintSet.WRAP_CONTENT);
        centerSet.connect(bbid, ConstraintSet.LEFT, pid, ConstraintSet.LEFT, 20);
        centerSet.connect(bbid, ConstraintSet.TOP, pid, ConstraintSet.TOP, 20);
        centerSet.connect(bbid, ConstraintSet.RIGHT, pid, ConstraintSet.RIGHT, 20);
        centerSet.connect(bbid, ConstraintSet.BOTTOM, gbid, ConstraintSet.BOTTOM, 20);

        // position the green button
        centerSet.constrainHeight(gbid,ConstraintSet.WRAP_CONTENT);
        centerSet.constrainWidth(gbid,ConstraintSet.WRAP_CONTENT);
        centerSet.connect(gbid, ConstraintSet.LEFT, pid, ConstraintSet.LEFT, 20);
        centerSet.connect(gbid, ConstraintSet.TOP, bbid, ConstraintSet.TOP, 20);
        centerSet.connect(gbid, ConstraintSet.RIGHT, pid, ConstraintSet.RIGHT, 20);
        centerSet.connect(gbid, ConstraintSet.BOTTOM, rbid, ConstraintSet.BOTTOM, 20);

        // position the red button
        centerSet.constrainHeight(rbid,ConstraintSet.WRAP_CONTENT);
        centerSet.constrainWidth(rbid,ConstraintSet.WRAP_CONTENT);
        centerSet.connect(rbid, ConstraintSet.LEFT, pid, ConstraintSet.LEFT, 20);
        centerSet.connect(rbid, ConstraintSet.RIGHT, pid, ConstraintSet.RIGHT, 20);
        centerSet.connect(rbid, ConstraintSet.TOP, gbid, ConstraintSet.BOTTOM, 20);
        centerSet.connect(rbid, ConstraintSet.BOTTOM, pid, ConstraintSet.BOTTOM, 20);

        centerSet.applyTo(constraintLayout);

        /*Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);*/

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
